/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package login2;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class Login2Test {

    private Task task1;
    private Task task2;

    @BeforeEach
    public void setUp() {
        // Initialize the tasks with given test data
        task1 = new Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        task2 = new Task("Add Task Feature", "Create Add task feature to add task users", "Mike Smith", 10, "Doing");
    }

    @Test
    public void testTaskDescription() {
        // Test for task1
        boolean isValidDescription1 = task1.checkTaskDescription();
        assertEquals(true, isValidDescription1, "Task successfully captured");

        // Test for task2
        boolean isValidDescription2 = task2.checkTaskDescription();
        assertEquals(true, isValidDescription2, "Task successfully captured");
    }

    @Test
    public void testTaskID() {
        // Task IDs are auto-generated and should follow the pattern described
        assertEquals("LO:0:SON", task1.createTaskID());
        assertEquals("AD:1:ITH", task2.createTaskID());
    }

    @Test
    public void testTotalHours() {
        int totalHours = task1.returnTotalHours() + task2.returnTotalHours();
        assertEquals(18, totalHours);
    }
}
