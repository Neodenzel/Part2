/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package login2;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

class Task {
    private String taskName;
    private int taskNumber;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskID;
    private String taskStatus;

    private static int taskCounter = 0;

    public Task(String taskName, String taskDescription, String developerDetails, int taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskNumber = taskCounter++;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskID = createTaskID();
        this.taskStatus = taskStatus;
    }

    public boolean checkTaskDescription() {
        return taskDescription.length() <= 50;
    }

    public String createTaskID() {
        String taskInitials = taskName.substring(0, 2).toUpperCase();
        String devInitials = developerDetails.substring(developerDetails.length() - 3).toUpperCase();
        return taskInitials + ":" + taskNumber + ":" + devInitials;
    }

    public String printTaskDetails() {
        return "Task Status: " + taskStatus + "\n" +
               "Developer Details: " + developerDetails + "\n" +
               "Task Number: " + taskNumber + "\n" +
               "Task Name: " + taskName + "\n" +
               "Task Description: " + taskDescription + "\n" +
               "Task ID: " + taskID + "\n" +
               "Task Duration: " + taskDuration + " hours";
    }

    public int returnTotalHours() {
        return taskDuration;
    }
}

public class Login2 {
    private String username;
    private String password;
    private String firstName;
    private String lastName;
    private List<Task> tasks;

    public Login2() {
        this.username = "";
        this.password = "";
        this.firstName = "";
        this.lastName = "";
        this.tasks = new ArrayList<>();
    }

    public void registerUser() {
        String username = JOptionPane.showInputDialog(null, "Enter your username that has 5 characters in it(we recommend you use a underscore in your username):");
        String password = JOptionPane.showInputDialog(null, "Enter your password that has 8 characters in it (we recommend complicating it by using special characters):");
        String firstName = JOptionPane.showInputDialog(null, "Enter your first name:");
        String lastName = JOptionPane.showInputDialog(null, "Enter your last name:");

        if (!checkUserName(username)) {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted. Please ensure that your username contains an underscore and is no more than 5 characters in length.");
            return;
        }
        if (!checkPasswordComplexity(password)) {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted. Please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.");
            return;
        }

        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;

        JOptionPane.showMessageDialog(null, "User registered successfully.");
    }

    public boolean loginUser() {
        String enteredUsername = JOptionPane.showInputDialog(null, "Enter your username:");
        String enteredPassword = JOptionPane.showInputDialog(null, "Enter your password:");

        if (enteredUsername.equals(username) && enteredPassword.equals(password)) {
            JOptionPane.showMessageDialog(null, "Welcome, " + firstName + " " + lastName + ". It's great to see you again.");
            JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Username or password incorrect. Please try again.");
            return false;
        }
    }

    private boolean checkUserName(String username) {
        return username.length() <= 5 && username.contains("_");
    }

    private boolean checkPasswordComplexity(String password) {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*\\d.*") &&
               password.matches(".*[!@#$%^&*()-_=+\\|[{]};:'\",<.>/?].*");
    }

    private void addTasks() {
        int numberOfTasks = Integer.parseInt(JOptionPane.showInputDialog(null, "How many tasks do you wish to enter?"));

        for (int i = 0; i < numberOfTasks; i++) {
            String taskName = JOptionPane.showInputDialog(null, "Enter the task name:");
            String taskDescription = JOptionPane.showInputDialog(null, "Enter the task description:");
            if (taskDescription.length() > 50) {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
                i--; 
                continue;
            } else {
                JOptionPane.showMessageDialog(null, "Task successfully captured");
            }
            String developerDetails = JOptionPane.showInputDialog(null, "Enter the developer's first and last name:");
            int taskDuration = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the task duration (in hours):"));
            String[] statuses = {"To Do", "Done", "Doing"};
            String taskStatus = (String) JOptionPane.showInputDialog(null, "Select the task status:", "Task Status", JOptionPane.QUESTION_MESSAGE, null, statuses, statuses[0]);

            Task task = new Task(taskName, taskDescription, developerDetails, taskDuration, taskStatus);
            tasks.add(task);
            JOptionPane.showMessageDialog(null, task.printTaskDetails());
        }

        int totalHours = tasks.stream().mapToInt(Task::returnTotalHours).sum();
        JOptionPane.showMessageDialog(null, "Total number of hours: " + totalHours);
    }

    private void showMenu() {
        while (true) {
            String[] options = {"Add tasks", "Show report", "Quit"};
            int choice = JOptionPane.showOptionDialog(null, "Choose an option:", "Menu", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            switch (choice) {
                case 0:
                    addTasks();
                    break;
                case 1:
                    JOptionPane.showMessageDialog(null, "Coming Soon");
                    break;
                case 2:
                    return;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice, please try again.");
                    break;
            }
        }
    }

    public static void main(String[] args) {
        Login2 login = new Login2();
        JFrame frame = new JFrame("Login System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);
        frame.setVisible(true);

        int option = JOptionPane.showConfirmDialog(frame, "Do you want to register a new user?", "Register User", JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            login.registerUser();
        }

        while (!login.loginUser()) {
            
        }

        login.showMenu();
    }
}
